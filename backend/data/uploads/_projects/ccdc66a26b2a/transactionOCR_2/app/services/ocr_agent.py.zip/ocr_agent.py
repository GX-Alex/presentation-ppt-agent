"""
流水提取 Agent 核心流程 — LangGraph 实现
参考「账单提取核心.yml」Dify DSL 的工作流逻辑：

  START
    ├── LLM 2: 从图片提取交易流水 → Markdown 表格
    ├── LLM 3: 从图片提取客户元数据 → JSON
    └── 代码执行: 合并结果
  END

使用 LangGraph 编排两个 LLM 节点并行执行，然后合并结果。
LLM 通过 OpenAI 兼容接口调用阿里云百炼 Qwen-VL。
"""
import json
import re
import logging
import operator
from typing import TypedDict, Optional, Annotated, List

from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import StateGraph, START, END

from app.config import (
    LLM_API_KEY,
    LLM_BASE_URL,
    LLM_EXTRACT_MODEL,
    LLM_META_MODEL,
    LLM_ENABLE_THINKING,
    LLM_EXTRACT_TEMPERATURE,
    LLM_META_TEMPERATURE,
    REQUEST_TIMEOUT,
)

logger = logging.getLogger("transaction_ocr")

# ══════════════════════════════════════════════════════════════
#  Prompt（与 Dify DSL 中的 prompt 完全一致）
# ══════════════════════════════════════════════════════════════

EXTRACT_TRANSACTIONS_PROMPT = """# 角色
你是一个专业的图片和PDF信息提取助手，专注于银行交易流水信息的深度提取。你不仅擅长OCR识别，更具备财务文档的结构化理解能力，能够处理复杂的表头合并逻辑。一共包含16个交易记录字段。如果有多张图片，按顺序提取每张图片的流水记录，最后合并只保留一个表头。如果某些图片没有表头，则从有表头图片推理当前图片的列信息。

# 任务
- **基础提取**：将用户上传的图片或PDF中的表格/列表/结构化信息提取为 Markdown 表格格式，严禁遗漏任何数据记录。
- **进阶字段映射**：识别全面理解原始图片信息后将原始流水信息按照金融语义理解能力映射为指定16个字段，具体字段见示例输出格式。
- **表头层级解析（核心）**：
  - 遇到表头存在“合并单元格”的情况（例如：“发生额”下方分为“借方”和“贷方”），**不要**只输出“借方”或“发生额”。
  - **必须执行语义融合**：将顶层分类标题与子列标题结合，生成完整的列名。
  - *逻辑示例*：若顶层是“发生额”，子列是“借方”，则最终列名应为“借方发生额”；若顶层是“交易对手信息”，子列是“对手机构”，则最终列名应为“对手机构信息”。
  - 如果某列没有上层合并标题（如“备注”），则保持原样。
- **异常处理**：
  - 图片可能存在倾斜、模糊或无表头的情况。你需要根据“列数据的视觉特征”和“通用金融常识”来推断每一列的含义并补全列名。
  - 图中的字段可能因排版被拆分为多行，请结合上下文合并字段值。

# 输出要求
1. **格式规范**：必须使用标准 Markdown 表格语法。
2. **表头处理**：第一行为表头，**必须是经过语义融合后的完整列名**（即解决上述合并单元格问题），用 | 分隔。
3. **分隔符**：第二行为分隔符 `|------|------|------|`，每个单元格对应的分隔符长度固定为 6 个 `-`。
4. **数据完整性**：后续每行为一条数据记录，不要省略数据记录信息。
5. **禁止前缀**：直接以表格开头，不要输出 "Here is the table" 等 markdown 代码块标记（```markdown）。

# 示例输出格式
| 流水号 | 交易日期 | 交易时间 | 对方户名 | 借贷标志 | 交易金额 | 账户余额 | 币种 | 对方账户 | 对方开户行 | 交易渠道 | 交易类型 | 交易用途 | 摘要 | 附言 | 商户号 |
|------|------|------| 
|| 2023-10-01 ||| 借 | 12 | 100 | 人民币 |||||||||

## 注意点
###1、抽取所有流水
###2、图片中字段内容可能会和待抽取的字段有出入,需利用语义理解能力映射为指定字段，重要映射逻辑案例如下：
####2.1借贷标志规则（重要！）
规则1：收入/支出标识映射
| 原数据标识 | 输出值 |
|-----------|--------|
| 收入、进账、收款、存入、收 | 贷 |
| 支出、出账、付款、消费、转出、支 | 借 |
| 其他（无法判断） | 不填，保持为空 |
规则2：借贷符号标识映射
| 原数据标识 | 输出值 |
|-----------|--------|
| +、C、CR、CREDIT、贷方 | 贷 |
| -、D、DR、DEBIT、借方 | 借 |
---
####2.2 交易金额规则（重要！）
规则1：金额必须为正数
- **所有金额必须输出为正数**
- 通过 `借贷标志` 字段来区分收入/支出
- **不允许输出负数金额**
规则2：金额正负与借贷标志的对应关系
| 原数据形式 | 处理方式 |
|-----------|---------|
| 原金额为正（如：+1000、1000） | 交易金额 = 1000，借贷标志 = 贷 |
| 原金额为负（如：-500） | 交易金额 = 500（取绝对值），借贷标志 = 借 |
| 有"收入"/"支出"标识 | 交易金额 为正数，借贷标志 按"借贷标志规则"填写 |
| 同时有正负金额（如：+1000、-500） | 交易金额 取绝对值，正数对应贷，负数对应借 |
规则3：金额格式
- 保留两位小数，如 1000.00
- 移除千分位逗号，如 1,000.00 → 1000.00
- 移除货币符号，如 ¥1000、￥1000 → 1000.00
---
####2.3 日期时间规则
规则1：日期格式
- 标准格式：YYYY-MM-DD（必须）
- 支持识别：2024-01-15、2024/01/15、20240115、2024年1月15日
- **输出时统一转换为 YYYY-MM-DD 格式，如果原日期字段只有月和日，则需要从表头识别相关记账起止日期进行补充。**
规则2： 时间格式
- 标准格式：HH:MM:SS（可选）
- 支持识别：14:30:00、14:30、143000
- **输出时统一转换为 HH:MM:SS 格式**
规则3： 处理方式
- 如果日期时间合并在一起（如 "2024-01-15 14:30:00"），需拆分为：
  - 交易时间= "2024-01-15"
  - 交易日期 = "14:30:00"
---
###3、组合字段拆分规则
- 如果遇到原始字段“对方户名/账号”格式（如 "张三/6222***1234"）需以“/”为分隔符拆分为：对方户名 = "张三”，对方账号 = "6222***1234”。
###4、账号清洗，去除账号两边的特殊字符（/、-、#）。
###5、脏数据过滤，跳过空白行、跳过只有表头关键词的行、跳过所有字段都为"-"或空白的行。
###6、映射完成后若图片中没有相关的字段则置空。
###7、每条记录都有16个字段，不要漏掉。
"""

EXTRACT_METADATA_PROMPT = """从提供的银行对账单图片中，仅从表头区域提取"客户名称"和"客户账号"和"账户所属机构"三个字段。请严格按以下规则处理： "客户名称"、"客户账号"、"账户所属机构"可能有其他别名，例如：户名、账户号、开户机构等等
若字段不存在或为空，则返回 null；输出必须为标准 JSON 格式。 不解析正文交易明细，仅聚焦表头。 示例输出： {"客户名称": "宁波涌畔建筑设计咨询有限公司", "客户账号": "634313601"，"账户所属机构"："中国民生银行股份有限公司"}"""


# ══════════════════════════════════════════════════════════════
#  LangGraph State
# ══════════════════════════════════════════════════════════════

def _concat_errors(a: list[str], b: list[str]) -> list[str]:
    return (a or []) + (b or [])


class AgentState(TypedDict):
    image_urls: List[str]  # 图片 URL 数组（支持多图一次请求）
    transactions_md: Optional[str]
    metadata_json: Optional[str]
    merged_result: Optional[str]
    errors: Annotated[list[str], _concat_errors]


# ══════════════════════════════════════════════════════════════
#  LLM 实例（OpenAI 兼容方式调用百炼）
# ══════════════════════════════════════════════════════════════

def _get_llm(model: str, temperature: float = 0.1) -> ChatOpenAI:
    """创建 LLM 实例，Qwen3 系列自动添加非思考模式参数"""
    kwargs = dict(
        model=model,
        api_key=LLM_API_KEY,
        base_url=LLM_BASE_URL,
        temperature=temperature,
        timeout=REQUEST_TIMEOUT,
    )
    # Qwen3 系列支持 enable_thinking 控制思考模式
    # 非思考模式：输出更稳定、速度更快，适合结构化信息提取
    if not LLM_ENABLE_THINKING:
        kwargs["extra_body"] = {"enable_thinking": False}
    return ChatOpenAI(**kwargs)


# ══════════════════════════════════════════════════════════════
#  节点函数
# ══════════════════════════════════════════════════════════════

def extract_transactions(state: AgentState) -> dict:
    """LLM 2: 从图片数组提取交易流水 Markdown 表格（支持多图一次请求）"""
    image_urls = state["image_urls"]
    logger.info("[Node:extract_transactions] 开始 — 共 %d 张图片", len(image_urls))
    try:
        llm = _get_llm(LLM_EXTRACT_MODEL, temperature=LLM_EXTRACT_TEMPERATURE)
        # 构建多图片内容列表
        image_contents = [
            {"type": "image_url", "image_url": {"url": url, "detail": "low"}}
            for url in image_urls
        ]
        messages = [
            SystemMessage(content=EXTRACT_TRANSACTIONS_PROMPT),
            HumanMessage(content=image_contents),
        ]
        # 打印请求报文（system prompt 前 200 字）
        logger.debug(
            "[Node:extract_transactions] LLM请求报文 — model=%s  图片数=%d  system_prompt(200)=%s",
            LLM_EXTRACT_MODEL, len(image_urls), EXTRACT_TRANSACTIONS_PROMPT[:200],
        )
        resp = llm.invoke(messages)
        content = resp.content
        # 打印响应报文（全量）
        logger.info(
            "[Node:extract_transactions] LLM响应报文 — 长度=%d字\n%s",
            len(content), content,
        )
        return {"transactions_md": content}
    except Exception as e:
        logger.error("[Node:extract_transactions] 失败: %s", e, exc_info=True)
        return {"transactions_md": "", "errors": [f"extract_transactions: {e}"]}


def extract_metadata(state: AgentState) -> dict:
    """LLM 3: 从图片数组中逐张查找含表头的图片，提取客户元数据 JSON"""
    image_urls = state["image_urls"]
    logger.info("[Node:extract_metadata] 开始 — 共 %d 张图片，逐张查找表头", len(image_urls))
    try:
        llm = _get_llm(LLM_META_MODEL, temperature=LLM_META_TEMPERATURE)
        last_content = "{}"

        for i, url in enumerate(image_urls):
            messages = [
                SystemMessage(content=EXTRACT_METADATA_PROMPT),
                HumanMessage(content=[
                    {"type": "image_url", "image_url": {"url": url, "detail": "low"}},
                ]),
            ]
            logger.debug(
                "[Node:extract_metadata] LLM请求报文 — model=%s  图片=%d/%d",
                LLM_META_MODEL, i + 1, len(image_urls),
            )
            resp = llm.invoke(messages)
            content = resp.content
            last_content = content
            logger.info(
                "[Node:extract_metadata] 图片 %d/%d LLM响应 — 长度=%d字\n%s",
                i + 1, len(image_urls), len(content), content,
            )

            # 检查是否获得有效元数据（至少一个非 null 字段）
            json_clean = re.sub(r"```(?:json)?\s*|\s*```", "", content.strip())
            try:
                metadata = json.loads(json_clean)
                if any(v is not None for v in metadata.values()):
                    logger.info("[Node:extract_metadata] 图片 %d 包含有效表头，停止查找", i + 1)
                    return {"metadata_json": content}
            except json.JSONDecodeError:
                pass

        # 所有图片均未找到有效元数据，返回最后一次响应
        logger.warning("[Node:extract_metadata] 所有 %d 张图片均未找到有效表头元数据", len(image_urls))
        return {"metadata_json": last_content}
    except Exception as e:
        logger.error("[Node:extract_metadata] 失败: %s", e, exc_info=True)
        return {"metadata_json": "{}", "errors": [f"extract_metadata: {e}"]}


def merge_results(state: AgentState) -> dict:
    """代码执行 2: 合并流水 Markdown + 元数据 JSON → 最终 JSON"""
    logger.info("[Node:merge_results] 开始合并")
    logger.debug(
        "[Node:merge_results] 输入 transactions_md(前200)=%s",
        (state.get("transactions_md") or "")[:200],
    )
    logger.debug(
        "[Node:merge_results] 输入 metadata_json=%s",
        state.get("metadata_json", ""),
    )
    try:
        markdown_text = state.get("transactions_md", "")
        json_text = state.get("metadata_json", "{}")

        # 清理 JSON 包装
        json_clean = re.sub(r"```(?:json)?\s*|\s*```", "", json_text.strip())
        try:
            metadata = json.loads(json_clean)
        except json.JSONDecodeError:
            logger.warning("元数据 JSON 解析失败，使用空字典。原文: %s", json_clean[:200])
            metadata = {}

        result = {
            **metadata,
            "transactions": markdown_text.strip(),
        }

        merged_str = json.dumps(result, ensure_ascii=False, indent=2)
        logger.info(
            "[Node:merge_results] 合并完成 — 共%d字\n%s",
            len(merged_str), merged_str[:500],
        )
        return {"merged_result": merged_str}
    except Exception as e:
        logger.error("merge_results 失败: %s", e, exc_info=True)
        return {"merged_result": None, "errors": [f"merge_results: {e}"]}


# ══════════════════════════════════════════════════════════════
#  构建 LangGraph 工作流
# ══════════════════════════════════════════════════════════════

def build_ocr_graph() -> StateGraph:
    """
    构建 OCR Agent Graph：

    START ─┬─► extract_transactions ─┐
           └─► extract_metadata     ─┤
                                     └─► merge_results ─► END
    """
    graph = StateGraph(AgentState)

    # 添加节点
    graph.add_node("extract_transactions", extract_transactions)
    graph.add_node("extract_metadata", extract_metadata)
    graph.add_node("merge_results", merge_results)

    # START → 两个 LLM 节点（并行 fan-out）
    graph.add_edge(START, "extract_transactions")
    graph.add_edge(START, "extract_metadata")

    # 两个 LLM 节点 → merge（fan-in）
    graph.add_edge("extract_transactions", "merge_results")
    graph.add_edge("extract_metadata", "merge_results")

    # merge → END
    graph.add_edge("merge_results", END)

    return graph


# 编译后的可执行工作流（模块级单例）
_compiled_graph = None


def get_ocr_agent():
    """获取编译后的 OCR Agent（懒加载单例）"""
    global _compiled_graph
    if _compiled_graph is None:
        g = build_ocr_graph()
        _compiled_graph = g.compile()
        logger.info("OCR Agent Graph 编译完成")
    return _compiled_graph


async def run_ocr_agent(image_urls: List[str]) -> Optional[dict]:
    """
    执行 OCR Agent，输入图片 URL / base64 data URL 数组，
    一次性将所有图片发送给 VLM，返回包含 transactions 和客户元数据的字典。

    Args:
        image_urls: 图片 URL 或 base64 data URL 列表（单张或多张）

    Returns:
        dict: {"客户名称": ..., "客户账号": ..., "账户所属机构": ..., "transactions": "..."}
        None: 执行失败
    """
    agent = get_ocr_agent()
    logger.info("[OCR Agent] 启动 — 共 %d 张图片", len(image_urls))
    try:
        result = await agent.ainvoke({"image_urls": image_urls})
        errors = result.get("errors") or []
        if errors:
            logger.warning("[OCR Agent] 节点错误: %s", errors)
        merged = result.get("merged_result")
        if merged:
            parsed = json.loads(merged)
            logger.info("[OCR Agent] 完成 — 字段: %s", list(parsed.keys()))
            return parsed
        logger.warning("[OCR Agent] 返回空结果")
        return None
    except Exception as e:
        logger.error("[OCR Agent] run_ocr_agent 失败: %s", e, exc_info=True)
        return None
